-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: bookshop
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `detail_order`
--

DROP TABLE IF EXISTS `detail_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detail_order` (
  `detailOrder_id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `details_id` int NOT NULL,
  `orderBookStatus_id` int DEFAULT NULL,
  `inventary_id` int DEFAULT NULL,
  PRIMARY KEY (`detailOrder_id`),
  UNIQUE KEY `inventary_id_UNIQUE` (`inventary_id`),
  KEY `order_id` (`order_id`),
  KEY `details_id` (`details_id`),
  KEY `orderBookStatus_id_idx` (`orderBookStatus_id`),
  CONSTRAINT `detail_order_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detail_order_ibfk_2` FOREIGN KEY (`details_id`) REFERENCES `book_details` (`details_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `inventary_id` FOREIGN KEY (`inventary_id`) REFERENCES `inventary` (`inventary_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail_order`
--

LOCK TABLES `detail_order` WRITE;
/*!40000 ALTER TABLE `detail_order` DISABLE KEYS */;
INSERT INTO `detail_order` VALUES (1,345,111190,3,35),(2,346,111178,3,31),(3,346,111182,3,33),(4,347,111187,3,34),(5,348,111219,3,40),(6,348,111197,3,36),(7,349,111201,3,37),(8,352,111191,3,60),(9,352,111184,3,54),(10,352,111210,3,51),(11,352,111190,3,45),(12,353,111210,3,48),(13,353,111190,3,55),(14,354,111189,3,56),(15,354,111189,3,57),(16,355,111210,3,49),(17,356,111180,3,32),(18,357,111201,3,41),(19,358,111202,3,43),(20,358,111178,3,64),(21,359,111189,3,58),(22,359,111184,3,52),(23,360,111191,3,63),(24,361,111218,2,65),(25,362,111217,2,68),(26,363,111217,2,67),(27,364,111200,1,NULL),(28,365,111193,1,NULL),(29,366,111193,1,NULL),(30,367,111197,1,NULL),(31,368,111194,1,NULL),(32,369,111206,1,NULL),(33,370,111212,1,NULL),(34,371,111218,2,66),(35,372,111216,1,NULL);
/*!40000 ALTER TABLE `detail_order` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-05 20:27:10
