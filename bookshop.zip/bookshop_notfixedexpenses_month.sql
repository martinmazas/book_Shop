-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: bookshop
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notfixedexpenses_month`
--

DROP TABLE IF EXISTS `notfixedexpenses_month`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notfixedexpenses_month` (
  `notFixedExpensesMonth_id` int NOT NULL AUTO_INCREMENT,
  `notFixedExpenses` int NOT NULL,
  `month_id` int NOT NULL,
  `year_id` int NOT NULL,
  `amount` float NOT NULL,
  PRIMARY KEY (`notFixedExpensesMonth_id`),
  KEY `notFixedExpenses` (`notFixedExpenses`),
  CONSTRAINT `notfixedexpenses_month_ibfk_1` FOREIGN KEY (`notFixedExpenses`) REFERENCES `notfixed_expenses` (`notFixedExpenses`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notfixedexpenses_month`
--

LOCK TABLES `notfixedexpenses_month` WRITE;
/*!40000 ALTER TABLE `notfixedexpenses_month` DISABLE KEYS */;
INSERT INTO `notfixedexpenses_month` VALUES (22,1,1,2020,26),(23,1,2,2020,30),(24,1,3,2020,30),(25,1,4,2020,35.5),(26,1,5,2020,27.7),(27,1,6,2020,33.3),(28,1,7,2020,35),(29,2,1,2020,42),(30,2,2,2020,45),(31,2,3,2020,40),(32,2,4,2020,38.78),(33,2,5,2020,29),(34,2,6,2020,50),(35,2,7,2020,44.48),(36,5,1,2020,17),(37,5,2,2020,29),(38,5,3,2020,70.3),(39,5,4,2020,35.5),(40,5,5,2020,39.9),(41,5,6,2020,33.3),(42,5,7,2020,27.45),(43,3,3,2016,84),(44,3,4,2018,64.928),(45,3,5,2019,38.376),(46,3,7,2019,51.168),(47,3,12,2019,52.5),(48,3,2,2020,63.68),(49,3,3,2020,78.3),(50,3,4,2020,48.7499),(51,3,5,2020,27.9999),(52,3,6,2020,137.5),(53,3,7,2020,271.108),(54,3,8,2020,95.85),(55,4,1,2020,7675.5),(56,4,2,2020,6039),(57,4,3,2020,5381),(58,4,4,2020,6732),(59,4,5,2020,7575.5),(60,4,6,2020,6737.5),(61,4,7,2020,5266);
/*!40000 ALTER TABLE `notfixedexpenses_month` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-05 20:27:13
