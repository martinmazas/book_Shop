-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: bookshop
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `delivery`
--

DROP TABLE IF EXISTS `delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery` (
  `delivery_id` int NOT NULL AUTO_INCREMENT,
  `deliveryType_id` int NOT NULL,
  `deliveryStatus_id` int NOT NULL,
  `detailOrder_id` int NOT NULL,
  PRIMARY KEY (`delivery_id`),
  UNIQUE KEY `detailOrder_id_UNIQUE` (`detailOrder_id`),
  KEY `deliveryType_id_idx` (`deliveryType_id`),
  KEY `deliveryStatus_id_idx` (`deliveryStatus_id`),
  CONSTRAINT `deliveryStatus_id` FOREIGN KEY (`deliveryStatus_id`) REFERENCES `delivery_status` (`deliveryStatus_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `deliveryType_id` FOREIGN KEY (`deliveryType_id`) REFERENCES `delivery_types` (`deliveryType_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detailOrder_id` FOREIGN KEY (`detailOrder_id`) REFERENCES `detail_order` (`detailOrder_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery`
--

LOCK TABLES `delivery` WRITE;
/*!40000 ALTER TABLE `delivery` DISABLE KEYS */;
INSERT INTO `delivery` VALUES (20,11,4,1),(21,21,4,2),(22,11,4,3),(23,12,4,4),(24,22,4,5),(25,22,4,6),(26,13,4,7),(27,11,2,8),(28,11,2,9),(29,22,3,10),(30,22,3,11),(31,13,4,12),(32,22,4,13),(33,22,4,14),(34,21,1,15),(35,21,1,16),(36,11,2,17),(37,22,4,18),(38,11,1,19),(39,11,1,20),(40,13,4,21),(41,22,1,22),(42,22,1,23);
/*!40000 ALTER TABLE `delivery` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-05 20:27:12
