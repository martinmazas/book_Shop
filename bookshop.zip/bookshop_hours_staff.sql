-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: bookshop
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hours_staff`
--

DROP TABLE IF EXISTS `hours_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hours_staff` (
  `hoursStaff_id` int NOT NULL AUTO_INCREMENT,
  `staff_id` int NOT NULL,
  `year_id` year NOT NULL,
  `month_id` int NOT NULL,
  `hours` float NOT NULL,
  PRIMARY KEY (`hoursStaff_id`),
  KEY `staff_id` (`staff_id`),
  CONSTRAINT `hours_staff_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`staff_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hours_staff`
--

LOCK TABLES `hours_staff` WRITE;
/*!40000 ALTER TABLE `hours_staff` DISABLE KEYS */;
INSERT INTO `hours_staff` VALUES (1,1,2020,1,70),(2,1,2020,2,20),(3,1,2020,3,44),(4,1,2020,4,38.5),(5,1,2020,5,50),(6,1,2020,6,20.75),(7,1,2020,7,33),(8,4,2020,1,41),(9,4,2020,2,66),(10,4,2020,3,25.25),(11,4,2020,4,30.5),(12,4,2020,5,62),(13,4,2020,6,55),(14,4,2020,7,39),(15,5,2020,1,35),(16,5,2020,2,42),(17,5,2020,3,36),(18,5,2020,4,60),(19,5,2020,5,37),(20,5,2020,6,29),(21,5,2020,7,36),(22,7,2020,1,44),(23,7,2020,2,19),(24,7,2020,3,29),(25,7,2020,4,40),(26,7,2020,5,36.5),(27,7,2020,6,60),(28,7,2020,7,22);
/*!40000 ALTER TABLE `hours_staff` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-05 20:27:09
