-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: bookshop
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `bookexpensespermonth`
--

DROP TABLE IF EXISTS `bookexpensespermonth`;
/*!50001 DROP VIEW IF EXISTS `bookexpensespermonth`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `bookexpensespermonth` AS SELECT 
 1 AS `MonthRef`,
 1 AS `YearRef`,
 1 AS `PaidPrice`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!50001 DROP VIEW IF EXISTS `transaction`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `transaction` AS SELECT 
 1 AS `MonthRef`,
 1 AS `YearRef`,
 1 AS `PaidPrice`,
 1 AS `Earn`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `totaldeliverypermonth`
--

DROP TABLE IF EXISTS `totaldeliverypermonth`;
/*!50001 DROP VIEW IF EXISTS `totaldeliverypermonth`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `totaldeliverypermonth` AS SELECT 
 1 AS `month(order_date)`,
 1 AS `year(order_date)`,
 1 AS `sum(weight*pricePerKg)`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `bookgainpermonth`
--

DROP TABLE IF EXISTS `bookgainpermonth`;
/*!50001 DROP VIEW IF EXISTS `bookgainpermonth`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `bookgainpermonth` AS SELECT 
 1 AS `MonthRef`,
 1 AS `YearRef`,
 1 AS `EarnPrice`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `salarypermonth`
--

DROP TABLE IF EXISTS `salarypermonth`;
/*!50001 DROP VIEW IF EXISTS `salarypermonth`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `salarypermonth` AS SELECT 
 1 AS `month_id`,
 1 AS `year_id`,
 1 AS `sum(hours*salaryPerHour)`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `bookexpensespermonth`
--

/*!50001 DROP VIEW IF EXISTS `bookexpensespermonth`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bookexpensespermonth` AS select month(`inventary`.`purchase_date`) AS `MonthRef`,year(`inventary`.`purchase_date`) AS `YearRef`,sum(`inventary`.`purchase_price`) AS `PaidPrice` from `inventary` group by month(`inventary`.`purchase_date`),year(`inventary`.`purchase_date`) order by `inventary`.`purchase_date` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `transaction`
--

/*!50001 DROP VIEW IF EXISTS `transaction`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `transaction` AS select `bookexpensespermonth`.`MonthRef` AS `MonthRef`,`bookexpensespermonth`.`YearRef` AS `YearRef`,`bookexpensespermonth`.`PaidPrice` AS `PaidPrice`,ifnull(`bookgainpermonth`.`EarnPrice`,0) AS `Earn` from (`bookexpensespermonth` left join `bookgainpermonth` on(((`bookexpensespermonth`.`MonthRef` = `bookgainpermonth`.`MonthRef`) and (`bookexpensespermonth`.`YearRef` = `bookgainpermonth`.`YearRef`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `totaldeliverypermonth`
--

/*!50001 DROP VIEW IF EXISTS `totaldeliverypermonth`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `totaldeliverypermonth` AS select month(`orders`.`order_date`) AS `month(order_date)`,year(`orders`.`order_date`) AS `year(order_date)`,sum((`sale_price`.`weight` * `delivery_types`.`pricePerKg`)) AS `sum(weight*pricePerKg)` from ((((`detail_order` join `orders` on((`detail_order`.`order_id` = `orders`.`order_id`))) join `delivery` on((`detail_order`.`detailOrder_id` = `delivery`.`detailOrder_id`))) join `sale_price` on((`detail_order`.`details_id` = `sale_price`.`details_id`))) join `delivery_types` on((`delivery`.`deliveryType_id` = `delivery_types`.`deliveryType_id`))) group by month(`orders`.`order_date`),year(`orders`.`order_date`) order by `orders`.`order_date` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `bookgainpermonth`
--

/*!50001 DROP VIEW IF EXISTS `bookgainpermonth`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bookgainpermonth` AS select month(`orders`.`order_date`) AS `MonthRef`,year(`orders`.`order_date`) AS `YearRef`,sum(`sale_price`.`price`) AS `EarnPrice` from ((`orders` join `detail_order` on((`orders`.`order_id` = `detail_order`.`order_id`))) join `sale_price` on((`detail_order`.`details_id` = `sale_price`.`details_id`))) group by month(`orders`.`order_date`),year(`orders`.`order_date`) order by `orders`.`order_date` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `salarypermonth`
--

/*!50001 DROP VIEW IF EXISTS `salarypermonth`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `salarypermonth` AS select `hours_staff`.`month_id` AS `month_id`,`hours_staff`.`year_id` AS `year_id`,sum((`hours_staff`.`hours` * `staff`.`salaryPerHour`)) AS `sum(hours*salaryPerHour)` from (`staff` join `hours_staff` on((`staff`.`staff_id` = `hours_staff`.`staff_id`))) group by `hours_staff`.`month_id`,`hours_staff`.`year_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-05 20:27:17
